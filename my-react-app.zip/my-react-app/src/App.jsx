import React from "react";
import "./App.css";
import Dashboard from "./screens/User/Dashboard"
function App() {
  return (
    <>
      <div className="w-full">
      <Dashboard/>
      </div>
    </>
  );
}

export default App;
